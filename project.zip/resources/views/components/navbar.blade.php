<nav class="sticky top-0 z-50 bg-primary font-poppins px-6 py-4 flex items-center justify-between shadow">
    <div class="flex items-center space-x-3">
        <img src="{{ asset('images/logo.jpeg') }}" alt="Logo Prodifa" class="h-10 w-10 object-cover rounded-full">
        <span class="font-bold text-xl whitespace-nowrap">LABORATORIUM PRODIFA</span>
    </div>

    <ul class="flex space-x-6 font-medium">
        {{-- Untuk guest dan semua role KECUALI mitra --}}
        @guest
            <li><a href="{{ route('home') }}" class="hover:text-yellow-700">Beranda</a></li>
            <li><a href="{{ route('tentang') }}" class="hover:text-yellow-700">Tentang</a></li>
            <li><a href="{{ route('reservasi') }}" class="hover:text-yellow-700">Reservasi</a></li>
            <li><a href="{{ route('login') }}" class="hover:text-yellow-700">Akun</a></li>
        @endguest

        @auth
            @if(Auth::user()->role === 'mitra')
                <li><a href="{{ route('mitra.welcome') }}" class="hover:text-yellow-700">Beranda</a></li>
                <li><a href="{{ route('rujukan.store') }}" class="hover:text-yellow-700">Rujukan</a></li>
                <li>
                    <button id="logoutBtn" class="hover:text-yellow-700">Akun</button>
                </li>
                
            @elseif($role === 'pasien')
                <li><a href="{{ route('home') }}" class="hover:text-yellow-700">Beranda</a></li>
                <li><a href="{{ route('reservasi') }}" class="hover:text-yellow-700">Reservasi</a></li>
                <li><button id="logoutTrigger" class="hover:text-yellow-700">Logout</button></li>
            @endif
        @endauth
    </ul>
</nav>

<!-- Modal Konfirmasi Logout -->
<div id="logoutModal" class="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-lg font-bold">Apakah Anda yakin ingin keluar?</h2>
        <div class="flex justify-end mt-4 space-x-4">
            <button id="cancelLogout" class="px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400">Batal</button>
            <form id="logoutForm" method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">Logout</button>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript untuk Menangani Modal -->
<script>
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutModal = document.getElementById('logoutModal');
    const cancelBtn = document.getElementById('cancelBtn');

    // Tampilkan modal konfirmasi logout saat tombol logout diklik
    logoutBtn.addEventListener('click', function() {
        logoutModal.classList.remove('hidden');
    });

    // Tutup modal jika tombol cancel diklik
    cancelBtn.addEventListener('click', function() {
        logoutModal.classList.add('hidden');
    });
</script>
