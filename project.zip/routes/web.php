<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\RujukanController;
use App\Http\Controllers\ReservasiController;

// Halaman utama
Route::view('/', 'landing.home')->name('home');
Route::view('/tentang', 'about.about')->name('tentang');

// Login & Register
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);

Route::get('/register', [RegisterController::class, 'create'])->name('register');
Route::post('/register', [RegisterController::class, 'store']);

// Logout
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Login Google
Route::get('auth/google', [GoogleController::class, 'redirectToGoogle'])->name('redirect.google');
Route::get('auth/google/callback', [GoogleController::class, 'handleGoogleCallback']);

Route::middleware(['auth', 'role:mitra'])->prefix('mitra')->group(function () {
    Route::view('/', 'mitra.welcome')->name('mitra.welcome');
    Route::view('/rujukan', 'mitra.reservasimitra')->name('rujukan');
    Route::get('/rujukan', [RujukanController::class, 'index'])->name('rujukan.index');
    Route::get('/rujukan', [RujukanController::class, 'create'])->name('rujukan.create');
    Route::post('/rujukan', [RujukanController::class, 'store'])->name('rujukan.store');
});

// Reservasi untuk semua (guest dan auth)
Route::view('/reservasi', 'reservasi')->name('reservasi'); // Hanya tampilan form
Route::post('/reservasi', [ReservasiController::class, 'store'])->name('reservasi.store'); // Proses form

