<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function create()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|string|email|max:255|unique:users',
            'phone'    => 'required|string|max:15',
            'password' => 'required|string|min:8|confirmed',
        ]);

        // 🆕 set role default sebagai mitra / pasien (bebas kamu atur)
        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'phone'    => $request->phone,
            'password' => Hash::make($request->password),
            'role'     => 'pasien',
        ]);

        Auth::login($user);

        // Arahkan ke dashboard sesuai role (biar konsisten dengan LoginController)
        if ($user->role === 'admin') {
            return redirect()->route('admin.dashboard');
        } elseif ($user->role === 'mitra') {
            return redirect()->route('mitra.welcome')->with('welcome', 'Selamat Datang, Mitra!');
        } elseif ($user->role === 'pasien') {
            return redirect()->route('login');
        }

        return redirect()->route('login')->with('success', 'Akun berhasil dibuat! Silakan login.');
    }
}

