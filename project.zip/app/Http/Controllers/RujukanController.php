<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\rujukan;
use Illuminate\Support\Facades\Storage;

class RujukanController extends Controller
{
    public function create()
    {
        return view('mitra.reservasimitra');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'nik' => 'required|string|size:16',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'tanggal_pemeriksaan' => 'required|date|after_or_equal:today',
            'jenis_pemeriksaan' => 'required|string|max:255',
            'detail_pemeriksaan' => 'required|string|max:255',
            'no_telepon' => 'required|string|max:20',
            'surat_rujukan' => 'required|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'catatan_dokter' => 'nullable|string',
        ]);

        // Handle file upload
        $filePath = $request->file('surat_rujukan')->store('surat_rujukan', 'public');

        $referral = Rujukan::create([
            'nama' => $validated['nama'],
            'alamat' => $validated['alamat'],
            'nik' => $validated['nik'],
            'tanggal_lahir' => $validated['tanggal_lahir'],
            'jenis_kelamin' => $validated['jenis_kelamin'],
            'tanggal_pemeriksaan' => $validated['tanggal_pemeriksaan'],
            'jenis_pemeriksaan' => $validated['jenis_pemeriksaan'],
            'detail_pemeriksaan' => $validated['detail_pemeriksaan'],
            'no_telepon' => $validated['no_telepon'],
            'surat_rujukan_path' => $filePath,
            'catatan_dokter' => $validated['catatan_dokter'],
        ]);

        return redirect()->route('mitra.welcome')->with('success', 'Data berhasil terkirim');
    }


}