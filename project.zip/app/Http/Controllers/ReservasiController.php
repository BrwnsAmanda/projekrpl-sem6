<?php

namespace App\Http\Controllers;

use App\Models\Reservasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ReservasiController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'alamat' => 'required|string',
            'nik' => 'required|digits:16',
            'telepon' => 'required|string|max:15',
            'tanggal_lahir' => 'required|date',
            'jadwal_pemeriksaan' => 'required|date|after_or_equal:today',
            'jenis' => 'required|string',
            'detail' => 'required|string',
            'rujukan' => 'required|in:Ya,Tidak',
            'surat_rujukan' => 'nullable|file|mimes:pdf,jpg,png|max:2048'
        ]);

        // Handle file upload
        $filePath = null;
        if ($request->hasFile('surat_rujukan')) {
            $filePath = $request->file('surat_rujukan')->store('rujukan', 'public');
        }

        // Create reservation
        $reservasi = Reservasi::create([
            'nama' => $validated['nama'],
            'jenis_kelamin' => $validated['jenis_kelamin'],
            'alamat' => $validated['alamat'],
            'nik' => $validated['nik'],
            'telepon' => $validated['telepon'],
            'tanggal_lahir' => $validated['tanggal_lahir'],
            'jadwal_pemeriksaan' => $validated['jadwal_pemeriksaan'],
            'jenis_pemeriksaan' => $validated['jenis'],
            'detail_pemeriksaan' => $validated['detail'],
            'punya_rujukan' => $validated['rujukan'],
            'surat_rujukan_path' => $filePath,
            'user_id' => auth()->id() // null jika guest
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Reservasi berhasil dibuat. Admin akan menghubungi Anda segera.',
            'data' => [
                'nama' => $validated['nama'],
                'jenis_kelamin' => $validated['jenis_kelamin'],
                'jadwal_pemeriksaan' => $validated['jadwal_pemeriksaan'],
                'jenis_pemeriksaan' => $validated['jenis'],
                'detail_pemeriksaan' => $validated['detail'],
                'punya_rujukan' => $validated['rujukan'],
                'nomor_telepon' => $validated['telepon'] // Untuk dihubungi admin
            ]
        ]);
    }

    public function index()
    {
        $reservasis = auth()->user()->reservasis()->latest()->get();
        return view('reservasi.index', compact('reservasis'));
    }
}
