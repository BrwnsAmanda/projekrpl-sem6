<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rujukan extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama',
        'alamat',
        'nik',
        'tanggal_lahir',
        'jenis_kelamin',
        'tanggal_pemeriksaan',
        'jenis_pemeriksaan',
        'detail_pemeriksaan',
        'no_telepon',
        'surat_rujukan_path',
        'catatan_dokter'
    ];

    protected $casts = [
        'tanggal_lahir' => 'date',
        'tanggal_pemeriksaan' => 'date',
    ];
}