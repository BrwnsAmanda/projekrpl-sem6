<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rujukan Pasien</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/flowbite@1.4.1/dist/flowbite.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-cream font-poppins">

    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="max-w-5xl mx-auto px-6 py-8">
        <!-- Banner Section -->
        <div class="bg-secondary text-center text-white p-6 rounded-lg space-y-2">
            <h2 class="text-lg font-bold">Rujukan Pasien</h2>
            <p> Rujukan Pasien ke Laboratorium adalah layanan yang digunakan untuk mengarahkan pasien melakukan pemeriksaan medis lebih lanjut di laboratorium.
            Melalui sistem ini, pasien mendapatkan surat rujukan resmi dari tenaga medis agar dapat melakukan tes atau analisis sesuai kebutuhan diagnosis.</p>
        </div>

        <!-- Form Section -->
        <div class="bg-white p-8 rounded-lg shadow-md mt-8">
            <h2 class="text-2xl font-bold mb-6">Form Rujukan Pasien</h2>
            <form id="rujukanForm" action="<?php echo e(route('rujukan.store')); ?>" method="POST" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php echo csrf_field(); ?>

                <!-- Input Fields -->
                <div>
                    <label class="block font-semibold text-sm mb-1">Nama</label>
                    <input type="text" name="nama" placeholder="Nama Lengkap" class="w-full border border-gray-300 rounded-md px-4 py-2" />
                </div>

                <div>
                    <label class="block font-semibold text-sm mb-1">Alamat</label>
                    <input type="text" name="alamat" placeholder="Alamat Lengkap" class="w-full border border-gray-300 rounded-md px-4 py-2" />
                </div>

                <div>
                    <label class="block font-semibold text-sm mb-1">No. NIK</label>
                    <input type="text" name="nik" placeholder="Nomor Induk Kependudukan" class="w-full border border-gray-300 rounded-md px-4 py-2" />
                </div>

                <div>
                    <label class="block font-semibold text-sm mb-1">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="w-full border border-gray-300 rounded-md px-4 py-2" />
                </div>

                <div>
                    <label for="jenis_kelamin" class="block font-semibold text-sm mb-1">Jenis Kelamin</label>
                    <div class="relative">
                        <button id="dropdownGenderButton" data-dropdown-toggle="dropdownGender"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md bg-white shadow-sm text-left flex justify-between items-center"
                            type="button">
                            <span id="genderText">Pilih</span>
                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        <div id="dropdownGender" class="z-10 hidden bg-white rounded-lg shadow w-full mt-2">
                            <ul class="py-2 text-sm text-gray-700" aria-labelledby="dropdownGenderButton">
                                <li><a href="#" onclick="selectGender('Laki-laki', event)"
                                        class="block px-4 py-2 hover:bg-gray-100">Laki-laki</a></li>
                                <li><a href="#" onclick="selectGender('Perempuan', event)"
                                        class="block px-4 py-2 hover:bg-gray-100">Perempuan</a></li>
                            </ul>
                        </div>
                        <input type="hidden" name="jenis_kelamin" id="genderInput">
                    </div>
                </div>


                <div>
                    <label class="block font-semibold text-sm mb-1">Penjadwalan Pemeriksaan</label>
                    <div class="grid">
                        <input type="date" name="tanggal_pemeriksaan" class="w-full border border-gray-300 rounded-md px-4 py-2" />
                    </div>
                </div>

                <!-- JENIS PEMERIKSAAN -->
            <div class="relative md:col-span-2">
                <label class="block font-semibold text-sm mb-1">Jenis Pemeriksaan</label>
                <button id="dropdownJenisButton" data-dropdown-toggle="dropdownJenis"
                    data-dropdown-placement="bottom-start"
                    class="w-full px-4 py-2 border border-gray-300 rounded-md bg-white shadow-sm text-left flex justify-between items-center"
                    type="button">
                    <span id="jenisText">Pilih Jenis Pemeriksaan</span>
                    <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div id="dropdownJenis" class="z-10 hidden bg-white rounded-lg shadow w-full mt-2">
                    <ul class="py-2 text-sm text-gray-700" aria-labelledby="dropdownJenisButton">
                        <li><a href="#" onclick="selectJenis('Hematologi', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Hematologi</a></li>
                        <li><a href="#" onclick="selectJenis('Diabetes Melitus', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Diabetes Melitus</a></li>
                        <li><a href="#" onclick="selectJenis('Profil Lemak', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Profil Lemak</a></li>
                        <li><a href="#" onclick="selectJenis('Fungsi Hati', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Fungsi Hati</a></li>
                        <li><a href="#" onclick="selectJenis('Fungsi Ginjal', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Fungsi Ginjal</a></li>
                        <li><a href="#" onclick="selectJenis('Urinalisa', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Urinalisa</a></li>
                        <li><a href="#" onclick="selectJenis('Hepatitis', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Hepatitis</a></li>
                        <li><a href="#" onclick="selectJenis('Imunologi', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Imunologi</a></li>
                        <li><a href="#" onclick="selectJenis('Infeksi Menular Seksual', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Infeksi Menular Seksual</a></li>
                        <li><a href="#" onclick="selectJenis('Lainnya', event)"
                                class="block px-4 py-2 hover:bg-gray-100">Lainnya</a></li>
                    </ul>
                </div>
                <input type="hidden" name="jenis_pemeriksaan" id="jenisInput">
            </div>

            <!-- DETAIL PEMERIKSAAN -->
            <div class="relative md:col-span-2">
                <label class="block font-semibold text-sm mb-1">Detail Pemeriksaan</label>
                <button id="dropdownDetailButton" data-dropdown-toggle="dropdownDetail"
                    class="w-full px-4 py-2 border border-gray-300 rounded-md bg-white shadow-sm text-left flex justify-between items-center"
                    type="button">
                    <span id="detailText">Pilih detail pemeriksaan</span>
                    <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div id="dropdownDetail" class="z-10 hidden bg-white rounded-lg shadow w-full mt-2">
                    <ul class="py-2 text-sm text-gray-700 list-none" id="detailOptions"></ul>
                </div>
                <input type="hidden" name="detail_pemeriksaan" id="detailInput">
            </div>

            <div class="flex-col md:flex-row gap-4 mb-4">
                <!-- No Telepon -->
                <div class="w-full mb-6">
                    <label class="block font-semibold text-sm mb-1">No Telepon</label>
                    <input type="text" name="no_telepon" placeholder="+6281343059039"
                        class="w-full border border-gray-300 rounded-md px-4 py-2" />
                </div>

                <!-- Upload Surat Rujukan -->
                <div id="upload-rujukan" class="block font-semibold text-sm mb-1">
                    <label for="surat_rujukan" class="block text-sm font-semibold text-gray-700 mb-2">Unggah Surat Rujukan</label>
                    <input type="file" id="surat_rujukan" name="surat_rujukan"
                        class="w-full border border-gray-300 rounded-md px-4 py-2 file:bg-secondary file:text-white"
                        accept=".pdf,image/*" onchange="previewFile(event)" />
                    <div id="preview-container" class="mt-4 hidden">
                        <div id="preview-box" class="bg-gray-100 p-4 rounded-md flex items-center justify-between">
                            <span id="file-name" class="text-sm font-medium text-gray-700"></span>
                            <button type="button" onclick="removePreview()"
                                class="ml-4 text-sm text-red-600 hover:underline">Hapus</button>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                 <label class="block font-semibold text-sm mb-1">Catatan Dokter (Opsional)</label>
                 <textarea name="catatan_dokter" rows="4" class="w-full border border-gray-300 rounded-md px-4 py-5"></textarea>
            </div>

            <div class="col-span-2 flex justify-center mt-4">
                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
                    Kirim
                </button>
            </div>
            </form>
        </div>

        <!-- Footer Section -->
        <section class="text-center py-10 bg-[#FAF6EB]">
            <h4 class="font-bold text-lg">Motto Kami</h4>
            <p class="italic font-semibold mt-2 text-lg">“Accurate, Care, and Trust”</p>
        </section>
    </div>

    <script>
        const pemeriksaanMap = {
            "Hematologi": ["Darah Rutin", "Laju Endap Darah (LED)", "Waktu Perdarahan (BT)", "Waktu Pembekuan (CT)",
                "Golongan Darah", "Golongan Darah + Rhesus"
            ],
            "Diabetes Melitus": ["Glukosa Darah Sewaktu", "Glukosa Darah Puasa", "Glukosa Darah 2 Jam PP", "TTGO",
                "HbA1c"
            ],
            "Profil Lemak": ["Cholesterol Total", "HDL Cholesterol", "LDL Cholesterol", "Trigliserida"],
            "Fungsi Hati": ["SGOT", "SGPT", "Bilirubin Total", "Bilirubin Direk", "Bilirubin Indirek", "Albumin"],
            "Fungsi Ginjal": ["Ureum", "Creatinin", "Asam Urat"],
            "Urinalisa": ["Urine Rutin", "Urine Lengkap + Sedimen"],
            "Hepatitis": ["HBsAg Kualitatif", "Anti HBs Kuantitatif", "Anti HCV Kualitatif"],
            "Imunologi": ["Widal", "Ns1", "IgG/IgM Dengue"],
            "Infeksi Menular Seksual": ["TPHA", "VDRL", "HIV", "Gram GO"],
            "Lainnya": ["Feces Rutin", "Analisa Sperma", "DDR (Malaria Apusan)", "BTA (Mikroskop)", "BTA Cuka-Cuki",
                "FT4", "TSH/TSH-S", "Ca 125", "Elektrolit", "B-Hcg", "Narkoba 1 Parameter", "Narkoba 3 Parameter",
                "Narkoba 6 Parameter"
            ]
        };

        function updateDetail() {
            const jenis = document.getElementById('jenisInput').value;
            const detailList = document.getElementById('detailOptions');
            const detailText = document.getElementById('detailText');
            const detailInput = document.getElementById('detailInput');

            detailList.innerHTML = ''; // Kosongkan dulu isinya
            detailText.innerText = 'Pilih detail pemeriksaan';
            detailInput.value = '';

            if (pemeriksaanMap[jenis]) {
                pemeriksaanMap[jenis].forEach(item => {
                    const li = document.createElement('li');
                    li.innerHTML =
                        `<a href="#" onclick="selectDetail('${item}', event)" class="block px-4 py-2 hover:bg-gray-100">${item}</a>`;
                    detailList.appendChild(li);
                });
            }
        }


        function selectGender(value) {
            event.preventDefault();
            document.getElementById('genderText').innerText = value;
            document.getElementById('genderInput').value = value;
            document.getElementById('dropdownGender').classList.add('hidden');
        }

        function selectJenis(value) {
            event.preventDefault();
            document.getElementById('jenisText').innerText = value;
            document.getElementById('jenisInput').value = value;

            updateDetail(); // jangan lupa panggil ini supaya detail diperbarui

            document.getElementById('dropdownJenis').classList.add('hidden');
        }


        function selectDetail(value) {
            event.preventDefault();
            document.getElementById('detailText').innerText = value;
            document.getElementById('detailInput').value = value;
            document.getElementById('dropdownDetail').classList.add('hidden');
        }



        function selectRujukan(value) {
            event.preventDefault();
            document.getElementById('rujukanText').innerText = value;
            document.getElementById('rujukanInput').value = value;

        }

        function previewFile(event) {
            const fileInput = event.target;
            const file = fileInput.files[0];
            const previewContainer = document.getElementById('preview-container');
            const fileNameSpan = document.getElementById('file-name');

            if (file) {
                fileNameSpan.textContent = file.name;
                previewContainer.classList.remove('hidden');
            } else {
                removePreview();
            }
        }

        function removePreview() {
            const fileInput = document.getElementById('surat_rujukan');
            const previewContainer = document.getElementById('preview-container');
            fileInput.value = "";
            previewContainer.classList.add('hidden');
        }

        // Hapus semua kode yang terkait dengan validasi logout
// Dan ganti dengan ini:

// Handler untuk modal logout
document.addEventListener('DOMContentLoaded', function() {
    const logoutTrigger = document.getElementById('logoutTrigger');
    const logoutModal = document.getElementById('logoutModal');
    const cancelLogout = document.getElementById('cancelLogout');

    if (logoutTrigger && logoutModal && cancelLogout) {
        logoutTrigger.addEventListener('click', function() {
            logoutModal.classList.remove('hidden');
        });

        cancelLogout.addEventListener('click', function() {
            logoutModal.classList.add('hidden');
        });
    }
});

// Validasi HANYA untuk form rujukan
$(document).ready(function() {
    $('#rujukanForm').on('submit', function(e) {
        e.preventDefault();

        // Validasi field
        const requiredFields = ['nama', 'alamat', 'nik', 'jenis_kelamin', 'tanggal_lahir', 'tanggal_pemeriksaan', 'no_telepon', 'surat_rujukan'];
        let isValid = true;

        requiredFields.forEach(field => {
            const value = $(`[name="${field}"]`).val().trim();
            if (!value) {
                isValid = false;
                $(`[name="${field}"]`).addClass('border-red-500');
            } else {
                $(`[name="${field}"]`).removeClass('border-red-500');
            }
        });

        if (!isValid) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Semua kolom wajib diisi!',
            });
            return false;
        }

        // Validasi nomor telepon
        const phoneRegex = /^[+0-9]{10,13}$/;
        if (!phoneRegex.test($('input[name="no_telepon"]').val().trim())) {
            Swal.fire({
                icon: 'error',
                title: 'Nomor Telepon Tidak Valid',
                text: 'Harap masukkan nomor telepon yang valid.',
            });
            return false;
        }

        // Submit form dengan AJAX
        $.ajax({
            url: $(this).attr('action'),
            method: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false,
            success: function(response) {
                // Reset seluruh form
                resetForm();

                // Tampilkan notifikasi sukses
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Data rujukan telah berhasil dikirim',
                    timer: 2000,
                    showConfirmButton: false
                });
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal',
                    text: 'Terjadi kesalahan saat mengirim data'
                });
            }
        });
    });

    // Fungsi untuk reset form secara menyeluruh
    function resetForm() {
        // Reset form utama
        $('#rujukanForm')[0].reset();

        // Reset input hidden dan teks dropdown
        $('#genderInput').val('');
        $('#genderText').text('Pilih');
        $('#jenisInput').val('');
        $('#jenisText').text('Pilih Jenis Pemeriksaan');
        $('#detailInput').val('');
        $('#detailText').text('Pilih detail pemeriksaan');

        // Reset preview file
        $('#preview-container').addClass('hidden');
        $('#surat_rujukan').val('');

        // Reset kelas error
        $('.border-red-500').removeClass('border-red-500');
    }
});
    </script>
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH /Users/amandaputri/projekrpl-sem6/resources/views/mitra/reservasimitra.blade.php ENDPATH**/ ?>